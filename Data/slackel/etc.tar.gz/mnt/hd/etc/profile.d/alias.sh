alias ls='ls -lhF --group-directories-first --color'
alias vi='vim'

